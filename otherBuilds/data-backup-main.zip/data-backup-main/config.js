module.exports.serviceAccount = require("./church-backend-dbf84-firebase-adminsdk-elg3i-956b61e243.json");

module.exports.collections = [
  "death",
  "death_archive",
  "donation",
  "events",
  "marriage",
  "marriage_archive",
  "requests",
  "requests_archive",
  "schedule",
  "schedule_archive",
];
