## instructions of use

run the command:

To Backup    
**node backup (name_of_collection)**

To Restore    
**node restore (name_of_collection)**

***collections available:***
- death
- death_archive
- donation
- events
- marriage
- marriage_archive
- requests
- requests_archive
- schedule
- schedule_archive

*note:* to backup or restore all, pass "all".

*Example:<br/>*
**node backup all** or **node restore all**
